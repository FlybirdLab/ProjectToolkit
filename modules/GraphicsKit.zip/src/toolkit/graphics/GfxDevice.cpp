/*
 * @Author: cubevlmu khfahqp@gmail.com
 * @LastEditors: cubevlmu khfahqp@gmail.com
 * Copyright (c) 2026 by FlybirdGames, All Rights Reserved.
 */

#include "GfxDevice.hpp"
#include "GfxBuffer.hpp"
#include "GfxContext.hpp"
#include "GfxManager.hpp"
#include "utils/GfxUtils.hpp"
#include "GfxPipelineState.hpp"
#include "GfxResource.hpp"
#include "GfxTargetPool.hpp"
#include "toolkit/debug/Logger.hpp"
#include "toolkit/debug/Profiler.hpp"
#include "toolkit/graphics/async/GfxTaskMgr.hpp"
#include "toolkit/types/StringBuilder.hpp"
#include "toolkit/utils/Convertor.hpp"
#include "async/GfxTaskExecutor.hpp"

namespace toolkit
{

    struct GfxDevice::PrivateData
    {
        GfxTaskManager tskMgr;
        GfxPipelineState *copyLinearPS = nullptr;
        GfxPipelineState *clearPS = nullptr;
        GfxPipelineState *decodeYUY2PS = nullptr;
        GfxPipelineState *decodeNV12PS = nullptr;
        GfxBuffer *fullscreenTriangleVB = nullptr;
    };

    GfxDevice *GfxDevice::sInstance = nullptr;

    void GfxDevice::onDeviceLostOrFatalError()
    {
        dumpResourcesToLog();
    }

    GfxDevice::GfxDevice(GfxBackendType type, GfxShaderProfile profile)
        : m_state(DeviceState::kMissing), m_backend(type), m_isRendering(false), m_isDisposing(false), m_wasVSyncUsed(false), m_drawGpuEventIndex(0), m_frameIndex(0), m_shaderProfile(profile), 
        m_featureLevel(GfxUtils::getFeatureLevel(profile)), m_res(TkMemory::newObject<PrivateData>()), m_resources(1024), totalMemory(0), isDebuging(false)
    {
        TK_ASSERT(m_backend != GfxBackendType::kUnknown);
    }

    GfxDevice::~GfxDevice()
    {
        TkMemory::deletePtr(m_res);

        // Unlink
        TK_ASSERT(GfxDevice::sInstance == this);
        GfxDevice::sInstance = nullptr;
    }

    bool GfxDevice::init()
    {
        // Clamp texture limits (eg. if driver reports higher value)
        limits.maxTexture1DSize = TkMath::min(limits.maxTexture1DSize, GFX_MAX_TEXTURE_SIZE);
        limits.maxTexture2DSize = TkMath::min(limits.maxTexture2DSize, GFX_MAX_TEXTURE_SIZE);
        limits.maxTexture3DSize = TkMath::min(limits.maxTexture3DSize, GFX_MAX_TEXTURE_SIZE);
        limits.maxTextureCubeSize = TkMath::min(limits.maxTextureCubeSize, GFX_MAX_TEXTURE_SIZE);
        limits.maxTexture1DArraySize = TkMath::min(limits.maxTexture1DArraySize, GFX_MAX_TEXTURE_ARRAY_SIZE);
        limits.maxTexture2DArraySize = TkMath::min(limits.maxTexture2DArraySize, GFX_MAX_TEXTURE_ARRAY_SIZE);
        limits.maxMipLevelsCount = TkMath::min(limits.maxMipLevelsCount, GFX_MAX_TEXTURE_MIP_LEVELS);

        m_res->tskMgr.setExecutor(createTasksExecutor());
        LogInfo("Total graphics memory: %s", TkConvertor::bytesToText(totalMemory));
        if (!limits.hasCompute)
            LogWarn("Compute Shaders are not supported");
        return true;
    }

    bool GfxDevice::initInternalResources()
    {
        return true;
    }

    bool GfxDevice::canDraw()
    {
        return m_state == DeviceState::kCreated || m_state == DeviceState::kReady;
    }

    void GfxDevice::addResource(GfxResource *resource)
    {
        m_resourcesLock.lock();
        TK_ASSERT(resource && !m_resources.contains(resource));
        m_resources.add(resource);
        m_resourcesLock.unlock();
    }

    void GfxDevice::removeResource(GfxResource *resource)
    {
        m_resourcesLock.lock();
        TK_ASSERT(resource && m_resources.contains(resource));
        m_resources.remove(resource);
        m_resourcesLock.unlock();
    }

    void GfxDevice::dumpResourcesToLog()
    {
        TkStringBuilder output;
        m_resourcesLock.lock();

        output.appendFormat("GPU Resources dump. Count: %i, total GPU memory used: %s", m_resources.count(), TkConvertor::bytesToText(getMemoryUsage()));
        output.appendLine();
        output.appendLine();

        const bool printTypes[(i32)GfxResType::MAX] =
            {
                true,  // RenderTarget
                true,  // Texture
                true,  // CubeTexture
                true,  // VolumeTexture
                true,  // Buffer
                true,  // Shader
                false, // PipelineState
                false, // Descriptor
                false, // Query
                false, // Sampler
            };
        for (i32 typeIndex = 0; typeIndex < (i32)GfxResType::MAX; typeIndex++)
        {
            const auto type = static_cast<GfxResType>(typeIndex);
            const auto printType = printTypes[typeIndex];

            output.appendFormat("Group: %is", type);
            output.appendLine();

            i32 count = 0;
            u64 memUsage = 0;
            for (i32 i = 0; i < m_resources.count(); i++)
            {
                const GfxResource *resource = m_resources[i];
                if (resource->getType() == type && resource->getMemoryUse() != 0)
                {
                    count++;
                    memUsage += resource->getMemoryUse();
                    auto str = resource->toString();
                    if (str.hasChars() && printType)
                    {
                        output.append('\t');
                        output.append(str);
                        output.appendLine();
                    }
                }
            }

            output.appendFormat("Total count: %i, memory usage: %s", count, TkConvertor::bytesToText(memUsage));
            output.appendLine();
            output.appendLine();
        }

        m_resourcesLock.unlock();
        LogInfo("%s", output.toStringView());
    }

    extern void clearVertexLayoutCache();

    void GfxDevice::preDispose()
    {
        mtx.lock();
        m_isDisposing = true;
        GfxTargetPool::flush();

        GFX_DEL_RESOURCE(m_res->copyLinearPS);
        GFX_DEL_RESOURCE(m_res->clearPS);
        GFX_DEL_RESOURCE(m_res->decodeYUY2PS);
        GFX_DEL_RESOURCE(m_res->decodeNV12PS);
        GFX_DEL_RESOURCE(m_res->fullscreenTriangleVB);
        clearVertexLayoutCache();

        mtx.unlock();

        // Release GPU resources memory and unlink from device
        // Note: after that no GPU resources should be used/created, only deleted
        m_resourcesLock.lock();
        for (i32 i = m_resources.count() - 1; i >= 0 && i < m_resources.count(); i--)
        {
            m_resources[i]->onDeviceDispose();
        }
        m_resources.clear();
        m_resourcesLock.unlock();
    }

    void GfxDevice::drawBegin()
    {
        m_isRendering = true;
        ++m_frameIndex;
    }

    void GfxDevice::drawEnd()
    {
        PROFILE_NAMED("GfxFrameEnd");
#if TK_PROFILER
        ProfilerGPU::onPresent();
#endif
        getMainContext()->flush();
        m_wasVSyncUsed = false;
        m_isRendering = false;

        GfxTargetPool::flush();
    }

    void GfxDevice::renderBegin()
    {
#if TK_PROFILER
        m_drawGpuEventIndex = ProfilerGPU::beginEvent(("Draw"));
#endif
    }

    void GfxDevice::renderEnd()
    {
#if TK_PROFILER
        ProfilerGPU::endEvent(m_drawGpuEventIndex);
#endif
    }

    GfxTaskContext *GfxDevice::createTasksContext()
    {
        return TkMemory::newObject<GfxTaskContext>(TkMemory::getDefault(), this);
    }

    GfxTaskExecutor *GfxDevice::createTasksExecutor()
    {
        return TkMemory::newObject<DefaultGfxTasksExecutor>();
    }

    void GfxDevice::draw()
    {
        drawBegin();

        auto context = getMainContext();

        context->frameBegin();
        renderBegin();

        m_res->tskMgr.frameBegin();
        m_res->tskMgr.frameEnd();

        renderEnd();
        context->frameEnd();

        drawEnd();
    }

    void GfxDevice::dispose()
    {
        preDispose();
    }

    u64 GfxDevice::getMemoryUsage()
    {
        u64 result = 0;
        m_resourcesLock.lock();
        for (i32 i = 0; i < m_resources.count(); i++)
            result += m_resources[i]->getMemoryUse();
        m_resourcesLock.unlock();
        return result;
    }

    TkArray<GfxResource *> GfxDevice::getResources()
    {
        m_resourcesLock.lock();
        TkArray<GfxResource *> result = m_resources;
        m_resourcesLock.unlock();
        return result;
    }

    GfxTaskManager *GfxDevice::getTaskManager() const
    {
        return &m_res->tskMgr;
    }

    GfxPipelineState *GfxDevice::getCopyLinearPS() const
    {
        return m_res->copyLinearPS;
    }

    GfxPipelineState *GfxDevice::getClearPS() const
    {
        return m_res->clearPS;
    }

    GfxPipelineState *GfxDevice::getDecodeYUY2PS() const
    {
        return m_res->decodeYUY2PS;
    }

    GfxPipelineState *GfxDevice::getDecodeNV12PS() const
    {
        return m_res->decodeNV12PS;
    }

    GfxBuffer *GfxDevice::getFullscreenTriangleVB() const
    {
        return m_res->fullscreenTriangleVB;
    }

}

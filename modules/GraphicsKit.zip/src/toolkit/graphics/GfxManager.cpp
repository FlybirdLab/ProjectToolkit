/*
 * @Author: cubevlmu khfahqp@gmail.com
 * @LastEditors: cubevlmu khfahqp@gmail.com
 * Copyright (c) 2026 by FlybirdGames, All Rights Reserved.
 */

#include "GfxManager.hpp"
#include "GfxDevice.hpp"
#include "GfxAdapter.hpp"
#include "toolkit/debug/Logger.hpp"
#include "toolkit/debug/Profiler.hpp"
#include "toolkit/graphics/async/GfxTaskMgr.hpp"
#include "toolkit/types/String.hpp"
#include "toolkit/types/Version.hpp"

namespace toolkit
{

    bool GfxManager::useVSync = false;
    TkMutex GfxManager::sharedMutex {};

#if GFX_API_NULL
    extern GfxDevice *createDeviceNull();
#endif
#if GFX_API_VULKAN
    extern GfxDevice *createDeviceVulkan();
#endif
#if GFX_API_DIRECTX11
    extern GfxDevice *createDeviceDX11();
#endif
#if GFX_API_DIRECTX12
    extern GfxDevice *createDeviceDX12();
#endif
#if GFX_API_OPENGL
    extern GfxDevice *createDeviceOGL();
#endif
#if GFX_API_METAL
    extern GfxDevice *createDeviceMetal();
#endif

    GfxDevice *GfxManager::getDevice()
    {
        return GfxDevice::sInstance;
    }

    static GfxDevice *createDeviceForBackend(GfxBackendType backend)
    {
        switch (backend)
        {
#if GFX_API_NULL
        case GfxBackendType::kNull:
            return createDeviceNull();
#endif
#if GFX_API_VULKAN
        case GfxBackendType::kVulkan:
            return createDeviceVulkan();
#endif
#if GFX_API_DIRECTX11
        case GfxBackendType::kDirectX11:
            return createDeviceDX11();
#endif
#if GFX_API_DIRECTX12
        case GfxBackendType::kDirectX12:
            return createDeviceDX12();
#endif
#if GFX_API_OPENGL
        case GfxBackendType::kOpenGL4_1:
        case GfxBackendType::kOpenGL4_4:
        case GfxBackendType::kOpenGLES3:
        case GfxBackendType::kOpenGLES3_1:
            return createDeviceOGL();
#endif
        default:
            return nullptr;
        }
    }

    bool GfxManager::createDevice(GfxBackendType backend)
    {
        TK_ASSERT(GfxDevice::sInstance == nullptr);

        GfxDevice *device = createDeviceForBackend(backend);
        if (!device)
            return false;

        GfxDevice::sInstance = device;
        if (!device->init() || !device->initInternalResources())
        {
            disposeDevice();
            return false;
        }

        return true;
    }

    void GfxManager::disposeDevice()
    {
        if (GfxDevice::sInstance)
        {
            GfxDevice::sInstance->dispose();
            TkMemory::deletePtr(GfxDevice::sInstance);
            GfxDevice::sInstance = nullptr;
        }
    }

    bool GfxManager::init()
    {
        TK_ASSERT(GfxDevice::sInstance == nullptr);

        // Create and initialize graphics device
        LogInfo("[Graphics] Creating device...");
        GfxPixelFormat::init();
        GfxDevice *device = nullptr;

        // Null
        if (!device)
        {
#if GFX_API_NULL
            device = createDeviceNull();
#else
            LogWarn("[Graphics] Null backend not available");
#endif
        }

        // Vulkan
        if (!device)
        {
#if GFX_API_VULKAN
            device = createDeviceVulkan();
#else
            LogWarn("Vulkan backend not available");
#endif
        }

        // DirectX 12
        if (!device)
        {
#if GFX_API_DIRECTX12
            device = createDeviceDX12();
#else
            LogWarn("DirectX 12 backend not available");
#endif
        }

        // DirectX 11 and DirectX 10
        if (!device)
        {
#if GFX_API_DIRECTX11
            device = createDeviceDX11();
#else
            LogWarn("DirectX 11 backend not available");
#endif
        }

        // Platform default
        if (!device)
        {
#if GFX_API_DIRECTX11
            if (!device)
                device = createDeviceDX11();
#endif
#if GFX_API_DIRECTX12
            if (!device)
                device = createDeviceDX12();
#endif
#if GFX_API_VULKAN
            if (!device)
                device = createDeviceVulkan();
#endif
        }

        // Null as a fallback
#if GFX_API_NULL
        if (!device)
            device = createDeviceNull();
#endif

        if (device == nullptr)
        {
            return false;
        }
        GfxDevice::sInstance = device;
        const TkString adapterDescription = device->getAdapter()->getDescription();
        const TkString driverVersion = device->getAdapter()->getDriverVersion().toString();
        LogInfo("GPU Device created: %s", adapterDescription.getText());
        LogInfo("Shader Profile: %i, Feature Level: %i, Driver: %s",
            static_cast<i32>(device->getShaderProfile()),
            static_cast<i32>(device->getFeatureLevel()),
            driverVersion.getText());

        // Initialize
        if (!device->init())
        {
            disposeDevice();
            return false;
        }
        if (device->isDebuging)
        {
#if !TK_DEBUG && !TK_LINUX // IsDebugToolAttached seams to be enabled on many Linux machines via VK_EXT_tooling_info
            // Block graphics debugging to protect contents
            TK_ASSERT(false && "[Graphics] Debugger attached.");
#endif
#if TK_WITH_PROFILER
            // Auto-enable GPU events
            ProfilerGPU::eventsEnabled = true;
#endif
        }
        if (!device->initInternalResources())
        {
            disposeDevice();
            return false;
        }

        return true;
    }

    void GfxManager::cleanup()
    {
        if (GfxDevice::sInstance)
        {
            // Start disposing
            GfxDevice::sInstance->getTaskManager()->dispose();
        }
    }

    void GfxManager::dispose()
    {
        // Device lifetime is controlled by the graphics manager.
    }

}

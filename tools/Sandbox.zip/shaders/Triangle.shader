struct VSIn
{
    float2 position : POSITION0;
    float4 color : COLOR0;
};

struct VSOut
{
    float4 position : SV_Position;
    float4 color : COLOR0;
};

META_VS(true, FEATURE_LEVEL_SM5)
META_VS_IN_ELEMENT(POSITION, 0, R32G32_Float, 0, 0, PER_VERTEX, 0, true)
META_VS_IN_ELEMENT(COLOR, 0, R32G32B32A32_Float, 0, 8, PER_VERTEX, 0, true)
VSOut VSMain(VSIn input)
{
    VSOut output;
    output.position = float4(input.position, 0.0, 1.0);
    output.color = input.color;
    return output;
}

META_PS(true, FEATURE_LEVEL_SM5)
float4 PSMain(VSOut input) : SV_Target0
{
    return input.color;
}
